import React from 'react';
import { contentList } from './Content';

function Contents({active, contents}) {

    return (
        <div>
            {'탭뷰입니다.'}
        </div>
    );
}

export default Contents;